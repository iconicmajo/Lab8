﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Pelotita : MonoBehaviour
{
    public int speed = 50;
    private Rigidbody rigidbody;
    public int force = 40;
    public int contador = 0;
    public Text score;
    //public bool lose;

    // Start is called before the first frame update
    void Start()
    {
        rigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        //Aqui es donde hago que la pelota se mueva 
        Vector3 movement = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
        rigidbody.AddForce(movement * speed);
        Vector3 escala = new Vector3(1, 1, 1);

        //Para cuando apache space salte la pelota
        if (Input.GetButtonDown("Jump") && Mathf.Abs(rigidbody.velocity.y) < 0.001) //Evita los saltos infinitos 
            Jump(); //llama la funcion

        //Aqui se destruye y reinstancia cuando toca el agua
       /* if (Collision gameObject.tag == "Obstaculo"){
            if (GameObject)
                Instantiate(GameObject, Vector3.zero, Quaternion.identity);
        }*/ 
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Obstaculo" && contador < 4)
        {
            Destroy(gameObject, .4f);
            GameController.lose = true;
        }
        if (collision.gameObject.tag == "Cilindro" )
        {
            Destroy(gameObject, .4f);
    
        }
    }

    //Aqui cuando pasa por una coin la destruye
        void OnTriggerEnter(Collider other)
        {
        contador = contador + 1;
        Destroy(other.gameObject);
        score.text = "Score: " + contador;
        }
        void FixedUpdate()
        {
            rigidbody.AddForce(Input.GetAxis("Horizontal")* force, 0, Input.GetAxis("Vertical")*force,0);
        }
        private void Jump()
        {
            rigidbody.AddForce(Vector3.up * 3, ForceMode.Impulse);
        }
    }