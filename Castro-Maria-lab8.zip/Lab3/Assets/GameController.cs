﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public GameObject nuevo;
    public static bool lose;
    public static bool pause;
    public Canvas panel;
    // Start is called before the first frame update
    void Start()
    {
        lose = true;
        pause = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (lose == false)
        {
            if (Input.GetKey(KeyCode.Return))
            {
                Vector3 start = new Vector3(12, 2, 11);
                Instantiate(nuevo, start, Quaternion.identity);
                lose = false;
            }
        }
        if (Input.GetKey(KeyCode.Escape))
        {
            if (pause)
                GameContinue();
            else
            {
                PauseGame();
            }
        }
    }
    public void PauseGame() { 
        
          // if (panel.gameObject.tag == "Pause")
        //    {
                //panel.gameObject.SetActive(true);
                Time.timeScale = 0.0f;
                panel.gameObject.SetActive(true);
                pause = true;

          //  }

        
    }
     public void GameContinue()
    {
        
           // if (panel.gameObject.tag == "Pause")
          //  {
                Time.timeScale = 1f;
                panel.gameObject.SetActive(false);
                pause = false;
          //  }
        
    }
}
