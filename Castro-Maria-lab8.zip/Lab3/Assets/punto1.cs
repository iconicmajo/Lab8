﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class punto1 : MonoBehaviour
{
    public Transform next;
    protected float debugDrawRadius = 1f;
   


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, debugDrawRadius);
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "NPC")
        {
         //   other.gameObject.GetComponent<NPC>().objetivo = next;
        }

    }
}
